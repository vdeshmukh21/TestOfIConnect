package com;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import com.opencsv.CSVWriter;

public class Test2
{
	public static void main(String[] args) 
	{
		String row="";
		try
		{
			BufferedReader br=new BufferedReader(new FileReader("cm29JAN2020bhav.csv"));
			BufferedReader br1=new BufferedReader(new FileReader("cm30JAN2020bhav.csv"));
			BufferedReader br2=new BufferedReader(new FileReader("cm31JAN2020bhav.csv"));
			FileWriter fout=new FileWriter("new2.csv");
			CSVWriter wr=new CSVWriter(fout);
			String[] title= {"Company Name","Range","DATR"};
			wr.writeNext(title);
			String[] addtotal= {};
			
			while ((row = br.readLine()) != null) 
			{
				String[] company=row.split(",");
				String[] range=row.split(",");
				//System.out.println("company details.."+company[0]+":"+company[3]+"-"+company[4]);
				range[0]=company[0];
				range[1]=company[3]+"-"+company[4];
				
				float high=Float.parseFloat(company[3]);
				float low=Float.parseFloat(company[4]);
				float avg=(high+low)/2;
				System.out.println(avg);
				range[2]=String.valueOf(avg); 
				String[] add= {range[0],range[1],range[2]};
				addtotal=add;
				wr.writeNext(addtotal);
			
			}
			br.close();
			wr.close();
			System.out.println("success");
		}
		catch(IOException e) 
		{
			e.printStackTrace();
		}
		
	}
}

