package com;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import com.opencsv.CSVWriter;

public class Test 
{
	public static void main(String[] args) 
	{
		String row="";
		try
		{
			BufferedReader br=new BufferedReader(new FileReader("cm29JAN2020bhav.csv"));
			BufferedReader br1=new BufferedReader(new FileReader("cm30JAN2020bhav.csv"));
			BufferedReader br2=new BufferedReader(new FileReader("cm31JAN2020bhav.csv"));
			FileWriter fout=new FileWriter("new29.csv");
			FileWriter fout1=new FileWriter("new30.csv");
			FileWriter fout2=new FileWriter("new31.csv");
			CSVWriter wr=new CSVWriter(fout);
			CSVWriter wr1=new CSVWriter(fout1);
			CSVWriter wr2=new CSVWriter(fout2);
			
			String[] title= {"column Name","Range","DATR"};
			wr.writeNext(title);
			wr1.writeNext(title);
			wr2.writeNext(title);
			
			/*code to find range and DATR for 29jan*/
			while ((row = br.readLine()) != null) 
			{
				String[] column=row.split(",");
				String[] range=row.split(",");
				//System.out.println("column details.."+column[0]+":"+column[3]+"-"+column[4]);
				range[0]=column[0];
				range[1]=column[3]+"-"+column[4];
				float high=Float.parseFloat(column[3]);
				float low=Float.parseFloat(column[4]);
				float avg=(high+low)/2;
				range[2]=String.valueOf(avg); 
				String[] add= {range[0],range[1],range[2]};
				wr.writeNext(add);
			}
			br.close();
			wr.close();
			
			/*code to find range and DATR for 30jan*/
			row="";
			while ((row = br1.readLine()) != null) 
			{
				String[] column=row.split(",");
				String[] range=row.split(",");
				//System.out.println("column details.."+column[0]+":"+column[3]+"-"+column[4]);
				range[0]=column[0];
				range[1]=column[3]+"-"+column[4];
				float high=Float.parseFloat(column[3]);
				float low=Float.parseFloat(column[4]);
				float avg=(high+low)/2;
				range[2]=String.valueOf(avg); 
				String[] add= {range[0],range[1],range[2]};
				wr1.writeNext(add);
			}
			br1.close();
			wr1.close();
		
			/*code to find range and DATR for 31jan*/
			row="";
			while ((row = br2.readLine()) != null) 
			{
				String[] column=row.split(",");
				String[] range=row.split(",");
				//System.out.println("column details.."+column[0]+":"+column[3]+"-"+column[4]);
				range[0]=column[0];
				range[1]=column[3]+"-"+column[4];
				float high=Float.parseFloat(column[3]);
				float low=Float.parseFloat(column[4]);
				float avg=(high+low)/2;
				range[2]=String.valueOf(avg); 
				String[] add= {range[0],range[1],range[2]};
				wr2.writeNext(add);
				
			}
			
			br2.close();
			wr2.close();
			System.out.println("success \nnow check csv files in conatining folder");
		}
		catch(IOException e) 
		{
			e.printStackTrace();
		}
		
	}
}
